ABDI CLOUD GAMING - Android project

This project packages the ABDI CLOUD GAMING demo interface as an Android app.
Minimum Android version: Android 6.0 (API 23). It is suitable for testing on Android 10.

BUILD WITHOUT ANDROID STUDIO (GitHub Actions)
1. Sign in to GitHub and create a NEW repository named ABDI-CLOUD-GAMING.
2. Extract this ZIP on your phone or computer.
3. Upload the CONTENTS of the ABDICloudGamingAndroid folder to the repository's main branch.
   Make sure the .github/workflows/build-apk.yml file is included.
4. Open the repository's Actions tab.
5. Select "Build ABDI CLOUD GAMING APK" and tap "Run workflow" (or wait for the first push build).
6. When the run finishes successfully, open it and download the artifact named
   "ABDI-CLOUD-GAMING-APK". Extract it to get app-debug.apk.
7. Transfer app-debug.apk to your Android phone and install it. Allow installation
   from that file manager/browser if Android asks.

IMPORTANT
- This builds a debug APK for testing; it is not a Play Store release-signed APK.
- The app is a WebView wrapper around the demo interface. It does NOT provide real
  cloud-game streaming yet. Real cloud play requires a streaming server and lawful
  access to the games being streamed.
- Do not upload signing keys, passwords, or private credentials to the repository.
